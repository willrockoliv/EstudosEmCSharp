﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerancaAluno
{
    class AlunoPos : Aluno
    {
        public AlunoPos(string p_ra, string p_nome) : base(p_ra, p_nome)
        {            
            MediaDeAprovacao = 7;
        }        

        public string Graduacao { get; set; }


        public override string ToString()
        {
            return base.ToString() +
                 "\t Graduação: " + Graduacao;
        }
    }
}
