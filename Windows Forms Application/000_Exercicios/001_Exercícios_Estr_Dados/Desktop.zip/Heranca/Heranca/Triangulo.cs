﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Heranca
{
    class Triangulo : FormaBasica
    {
        #region Propriedades e enumeradores

        public enum TipoTriangulo { isosceles, equilatero, escaleno };

        int ladoAC;

        public int LadoAC
        {
            get { return ladoAC; }
        }

        int ladoAB;

        public int LadoAB
        {
            get { return ladoAB; }
        }


        int ladoBC;

        public int LadoBC
        {
            get { return ladoBC; }
        }

        Point pontoA;

        public Point PontoA
        {
            get { return pontoA; }
            set { pontoA = value; }
        }
        Point pontoB;

        public Point PontoB
        {
            get { return pontoB; }
            set { pontoB = value; }
        }
        Point pontoC;

        public Point PontoC
        {
            get { return pontoC; }
            set { pontoC = value; }
        }

        #endregion

        

        public Triangulo(Point pontoA, Point pontoB, Point pontoC)
        {
            this.PontoA = pontoA;
            this.PontoB = pontoB;
            this.PontoC = pontoC;

            CalculaLados();
        }

        
        public TipoTriangulo TipoDoTriangulo()
        {
            if (ladoAB == ladoAC && ladoAC == ladoBC)
                return TipoTriangulo.equilatero;
            else if (ladoAB != ladoAC && ladoAC != ladoBC && ladoAB != ladoBC)
                return TipoTriangulo.escaleno;
            else
                return TipoTriangulo.isosceles;
        }


        private void CalculaLados()
        {
            ladoAB = Distance2D(pontoA, pontoB);
            ladoAC = Distance2D(pontoA, pontoC);
            ladoBC = Distance2D(pontoB, PontoC);
        }


        public int Distance2D(Point p1, Point p2)
        {
            int result = 0;
            double part1 = Math.Pow((p2.X - p1.X), 2);
            double part2 = Math.Pow((p2.Y - p1.Y), 2);
            double underRadical = part1 + part2;
            result = (int)Math.Sqrt(underRadical);
            return result;
        }



        public override double GetArea()
        {
            return  (ladoAB * ladoBC) / 2; 
        }

        public override double GetPerimetro()
        {
            return ladoAB + ladoBC + ladoAC;
        }

        public override void Desenhar(Control controle)
        {
            Graphics grafico = controle.CreateGraphics();
            Point[] pontos = new Point[] 
                    { 
                        pontoA, 
                        pontoB, 
                        pontoC
                    };

            grafico.DrawPolygon(Pens.Red, pontos);
        }
        

    }
}
