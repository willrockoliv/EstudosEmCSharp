﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Heranca
{
    class Retangulo : FormaBasica
    {
        int altura;

        public int Altura
        {
            get { return altura; }
            set
            {
                if (value < 0)
                    throw new Exception("Altura não pode ser negativa!");
                else
                    altura = value;
            }
        }



        int largura;

        public int Largura
        {
            get { return largura; }
            set
            {
                if (value < 0)
                    throw new Exception("Largura não pode ser negativa!");
                else
                    largura = value;
            }
        }


        public Retangulo(int altura, int largura)
        {
            this.Altura = altura;
            this.Largura = largura;

        }


        public override double GetArea()
        {
            return altura * largura;
        }

        public override double GetPerimetro()
        {
            return 2 * altura + 2 * largura;
        }

        
        public override void Desenhar(Control controle)
        {
            Graphics grafico = controle.CreateGraphics();
            grafico.DrawRectangle(Pens.Red, new Rectangle(50, 50, largura, altura));
        }


        public override string ToString()
        {
            return base.ToString() + " Lado: " + Largura +
                "  Altura: " + Altura;
        }


    }
}
