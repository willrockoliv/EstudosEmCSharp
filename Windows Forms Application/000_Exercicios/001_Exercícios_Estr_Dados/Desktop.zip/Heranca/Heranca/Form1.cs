﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Heranca
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// essa lista pode armazenar objetos da classe formabasica ou de
        /// seus descendentes! uau!
        /// </summary>
        List<FormaBasica> ListaFormas = new List<FormaBasica>();


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
                        
            Quadrado quadrado = new Quadrado(100);
            quadrado.Desenhar(panel1);
                       
            ListaFormas.Add(quadrado);

            PreencheInformacoes(quadrado);
        }



        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
            Retangulo retangulo = new Retangulo(100, 300);
            retangulo.Desenhar(panel1);

            ListaFormas.Add(retangulo);

            PreencheInformacoes(retangulo);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Refresh();

            Point pontoA = new Point(100,100);
            Point pontob = new Point(50,50);
            Point pontoc = new Point(200,50);
            
            Triangulo triangulo = new Triangulo(pontoA, pontob, pontoc);
            triangulo.Desenhar(panel1);

            ListaFormas.Add(triangulo);

            PreencheInformacoes(triangulo);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
            Circulo circulo = new Circulo(100);
            circulo.Desenhar(panel1);

            ListaFormas.Add(circulo);

            PreencheInformacoes(circulo);
        }



        private void PreencheInformacoes(FormaBasica forma)
        {
            listBox1.Items.Clear();

            listBox1.Items.Add("Área: " + forma.GetArea());
            listBox1.Items.Add("Perímetro: " + forma.GetPerimetro());
            

            if (forma is Quadrado)
            {
                listBox1.Items.Add("Lado: " + (forma as Quadrado).Lado);
            }
            else if (forma is Retangulo)
            {
                listBox1.Items.Add("Altura: " + (forma as Retangulo).Altura);
                listBox1.Items.Add("Largura: " + (forma as Retangulo).Largura);
            }
            else if (forma is Triangulo)
            {
                listBox1.Items.Add("Tipo: " + (forma as Triangulo).TipoDoTriangulo().ToString());
                listBox1.Items.Add("Lado AB: " + (forma as Triangulo).LadoAB);
                listBox1.Items.Add("Lado AC: " + (forma as Triangulo).LadoAC);
                listBox1.Items.Add("Lado BC: " + (forma as Triangulo).LadoBC);                
            }
            else // só sobrou o circulo...
            {
                listBox1.Items.Add("Raio: " + (forma as Circulo).Raio);                
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            btnListar.Enabled = false;
            foreach (FormaBasica forma in ListaFormas)
            {
                panel1.Refresh(); // limpa o panel para o novo desenho...
                forma.Desenhar(panel1);                
                PreencheInformacoes(forma);
                listBox1.Refresh();
                Thread.Sleep(2000); // aguarda 2 segundos
            }
            btnListar.Enabled = true;
                       
        }

        
    }
}