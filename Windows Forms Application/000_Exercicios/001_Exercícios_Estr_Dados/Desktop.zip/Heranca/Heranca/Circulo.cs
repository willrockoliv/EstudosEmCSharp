﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace Heranca
{
    class Circulo : FormaBasica
    {
        int raio;

        public int Raio
        {
            get { return raio; }
            set
            {
                if (value < 0)
                    throw new Exception("Raio não pode ser negativo!");
                else
                    raio = value;
            }
        }

        public Circulo(int raio)
        {
            this.Raio = raio;
        }



        public override double GetArea()
        {
            return Math.PI * raio * raio;
        }

        public override double GetPerimetro()
        {
            return 2 * Math.PI * raio;
        }

        public override void Desenhar(Control controle)
        {
            Graphics grafico = controle.CreateGraphics();
            grafico.DrawEllipse(Pens.Blue, 20, 20, raio*2, raio*2);
        }
    }
}
