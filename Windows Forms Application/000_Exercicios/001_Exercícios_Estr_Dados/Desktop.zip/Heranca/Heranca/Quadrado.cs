﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Heranca
{
    class Quadrado : FormaBasica
    {
        private int lado;

        public int Lado
        {            

            get { return lado; }
            set
            {
                if (value < 0)
                    throw new Exception("Lado não pode ser negativo!");
                else
                    lado = value;
            }
        }


        public Quadrado(int lado)
        {
            this.Lado = lado;
        }






        public override double GetArea()
        {
            return lado * lado;
        }

        public override double GetPerimetro()
        {
            return 4 * lado;
        }


        public override void Desenhar(Control controle)
        {
            Graphics grafico = controle.CreateGraphics();
            grafico.DrawRectangle(Pens.Red, new Rectangle(50, 50, lado, lado));
        }

       
    }
}
