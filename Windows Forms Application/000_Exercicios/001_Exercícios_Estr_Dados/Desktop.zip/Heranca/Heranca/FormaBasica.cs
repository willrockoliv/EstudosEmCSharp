﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Heranca
{
    abstract class FormaBasica : Object
    {

        public override string ToString()
        {
            return GetArea() + "  " + GetPerimetro();
        }

        public void Faznada()
        {
            Console.WriteLine("faço nada!");
        }


        public string NomeObjeto;

        public abstract double GetArea();
         

        public abstract double GetPerimetro();

        public abstract void Desenhar(Control controle);
    }
}
