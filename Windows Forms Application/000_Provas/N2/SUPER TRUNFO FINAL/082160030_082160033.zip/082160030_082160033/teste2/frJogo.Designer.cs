﻿namespace teste2
{
    partial class frJogo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frJogo));
            this.CartaJogFrente = new System.Windows.Forms.Panel();
            this.lblCodigoJog = new System.Windows.Forms.Label();
            this.txbNomeJog = new System.Windows.Forms.TextBox();
            this.lblHumanasForcaJog = new System.Windows.Forms.Label();
            this.lblMalandragemForcaJog = new System.Windows.Forms.Label();
            this.lblRaivaForcaJog = new System.Windows.Forms.Label();
            this.lblFomeForcaJog = new System.Windows.Forms.Label();
            this.lblSonoForcaJog = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.progressBarHumanasJog = new System.Windows.Forms.ProgressBar();
            this.progressBarMalandragemJog = new System.Windows.Forms.ProgressBar();
            this.progressBarRaivaJog = new System.Windows.Forms.ProgressBar();
            this.progressBarFomeJog = new System.Windows.Forms.ProgressBar();
            this.progressBarSonoJog = new System.Windows.Forms.ProgressBar();
            this.label4 = new System.Windows.Forms.Label();
            this.ptbImagemCartaJog = new System.Windows.Forms.PictureBox();
            this.CartaCompFrente = new System.Windows.Forms.Panel();
            this.lblCodigoComp = new System.Windows.Forms.Label();
            this.txbNomeComp = new System.Windows.Forms.TextBox();
            this.lblHumanasForcaComp = new System.Windows.Forms.Label();
            this.lblMalandragemForcaComp = new System.Windows.Forms.Label();
            this.lblRaivaForcaComp = new System.Windows.Forms.Label();
            this.lblFomeForcaComp = new System.Windows.Forms.Label();
            this.lblSonoForcaComp = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.progressBarHumanasComp = new System.Windows.Forms.ProgressBar();
            this.progressBarMalandragemComp = new System.Windows.Forms.ProgressBar();
            this.progressBarRaivaComp = new System.Windows.Forms.ProgressBar();
            this.progressBarFomeComp = new System.Windows.Forms.ProgressBar();
            this.progressBarSonoComp = new System.Windows.Forms.ProgressBar();
            this.label17 = new System.Windows.Forms.Label();
            this.ptbImagemCartaComp = new System.Windows.Forms.PictureBox();
            this.CartaJogVerso = new System.Windows.Forms.Panel();
            this.CartaCompVerso = new System.Windows.Forms.Panel();
            this.txbPontosJog = new System.Windows.Forms.TextBox();
            this.txbPontosComp = new System.Windows.Forms.TextBox();
            this.lblPontosJog = new System.Windows.Forms.Label();
            this.lblPontosComp = new System.Windows.Forms.Label();
            this.lblVs = new System.Windows.Forms.Label();
            this.txbTempoJogo = new System.Windows.Forms.TextBox();
            this.lblTempoJogo = new System.Windows.Forms.Label();
            this.TmTempoJogo = new System.Windows.Forms.Timer(this.components);
            this.txbCartasComp = new System.Windows.Forms.TextBox();
            this.txbCartasJog = new System.Windows.Forms.TextBox();
            this.lblCartasJog = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TempoPontos = new System.Windows.Forms.Timer(this.components);
            this.CartaJogFrente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbImagemCartaJog)).BeginInit();
            this.CartaCompFrente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbImagemCartaComp)).BeginInit();
            this.CartaJogVerso.SuspendLayout();
            this.CartaCompVerso.SuspendLayout();
            this.SuspendLayout();
            // 
            // CartaJogFrente
            // 
            this.CartaJogFrente.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CartaJogFrente.BackgroundImage = global::teste2.Properties.Resources.cartaFrente;
            this.CartaJogFrente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CartaJogFrente.Controls.Add(this.lblCodigoJog);
            this.CartaJogFrente.Controls.Add(this.txbNomeJog);
            this.CartaJogFrente.Controls.Add(this.lblHumanasForcaJog);
            this.CartaJogFrente.Controls.Add(this.lblMalandragemForcaJog);
            this.CartaJogFrente.Controls.Add(this.lblRaivaForcaJog);
            this.CartaJogFrente.Controls.Add(this.lblFomeForcaJog);
            this.CartaJogFrente.Controls.Add(this.lblSonoForcaJog);
            this.CartaJogFrente.Controls.Add(this.label1);
            this.CartaJogFrente.Controls.Add(this.label2);
            this.CartaJogFrente.Controls.Add(this.label3);
            this.CartaJogFrente.Controls.Add(this.label5);
            this.CartaJogFrente.Controls.Add(this.progressBarHumanasJog);
            this.CartaJogFrente.Controls.Add(this.progressBarMalandragemJog);
            this.CartaJogFrente.Controls.Add(this.progressBarRaivaJog);
            this.CartaJogFrente.Controls.Add(this.progressBarFomeJog);
            this.CartaJogFrente.Controls.Add(this.progressBarSonoJog);
            this.CartaJogFrente.Controls.Add(this.label4);
            this.CartaJogFrente.Controls.Add(this.ptbImagemCartaJog);
            this.CartaJogFrente.Location = new System.Drawing.Point(0, 0);
            this.CartaJogFrente.Name = "CartaJogFrente";
            this.CartaJogFrente.Size = new System.Drawing.Size(358, 535);
            this.CartaJogFrente.TabIndex = 0;
            // 
            // lblCodigoJog
            // 
            this.lblCodigoJog.AutoSize = true;
            this.lblCodigoJog.BackColor = System.Drawing.Color.SkyBlue;
            this.lblCodigoJog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCodigoJog.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoJog.ForeColor = System.Drawing.Color.Black;
            this.lblCodigoJog.Location = new System.Drawing.Point(17, 8);
            this.lblCodigoJog.Name = "lblCodigoJog";
            this.lblCodigoJog.Size = new System.Drawing.Size(2, 21);
            this.lblCodigoJog.TabIndex = 16;
            // 
            // txbNomeJog
            // 
            this.txbNomeJog.Location = new System.Drawing.Point(65, 8);
            this.txbNomeJog.Name = "txbNomeJog";
            this.txbNomeJog.ReadOnly = true;
            this.txbNomeJog.Size = new System.Drawing.Size(221, 20);
            this.txbNomeJog.TabIndex = 15;
            this.txbNomeJog.Text = "NOME";
            this.txbNomeJog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblHumanasForcaJog
            // 
            this.lblHumanasForcaJog.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHumanasForcaJog.AutoSize = true;
            this.lblHumanasForcaJog.BackColor = System.Drawing.Color.Transparent;
            this.lblHumanasForcaJog.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblHumanasForcaJog.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHumanasForcaJog.ForeColor = System.Drawing.Color.Black;
            this.lblHumanasForcaJog.Location = new System.Drawing.Point(8, 495);
            this.lblHumanasForcaJog.Name = "lblHumanasForcaJog";
            this.lblHumanasForcaJog.Size = new System.Drawing.Size(36, 19);
            this.lblHumanasForcaJog.TabIndex = 0;
            this.lblHumanasForcaJog.Tag = "";
            this.lblHumanasForcaJog.Text = "0 %";
            // 
            // lblMalandragemForcaJog
            // 
            this.lblMalandragemForcaJog.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMalandragemForcaJog.AutoSize = true;
            this.lblMalandragemForcaJog.BackColor = System.Drawing.Color.Transparent;
            this.lblMalandragemForcaJog.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblMalandragemForcaJog.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMalandragemForcaJog.ForeColor = System.Drawing.Color.Black;
            this.lblMalandragemForcaJog.Location = new System.Drawing.Point(8, 445);
            this.lblMalandragemForcaJog.Name = "lblMalandragemForcaJog";
            this.lblMalandragemForcaJog.Size = new System.Drawing.Size(36, 19);
            this.lblMalandragemForcaJog.TabIndex = 1;
            this.lblMalandragemForcaJog.Tag = "";
            this.lblMalandragemForcaJog.Text = "0 %";
            // 
            // lblRaivaForcaJog
            // 
            this.lblRaivaForcaJog.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRaivaForcaJog.AutoSize = true;
            this.lblRaivaForcaJog.BackColor = System.Drawing.Color.Transparent;
            this.lblRaivaForcaJog.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblRaivaForcaJog.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaivaForcaJog.ForeColor = System.Drawing.Color.Black;
            this.lblRaivaForcaJog.Location = new System.Drawing.Point(8, 397);
            this.lblRaivaForcaJog.Name = "lblRaivaForcaJog";
            this.lblRaivaForcaJog.Size = new System.Drawing.Size(36, 19);
            this.lblRaivaForcaJog.TabIndex = 2;
            this.lblRaivaForcaJog.Tag = "";
            this.lblRaivaForcaJog.Text = "0 %";
            // 
            // lblFomeForcaJog
            // 
            this.lblFomeForcaJog.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFomeForcaJog.AutoSize = true;
            this.lblFomeForcaJog.BackColor = System.Drawing.Color.Transparent;
            this.lblFomeForcaJog.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblFomeForcaJog.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFomeForcaJog.ForeColor = System.Drawing.Color.Black;
            this.lblFomeForcaJog.Location = new System.Drawing.Point(8, 349);
            this.lblFomeForcaJog.Name = "lblFomeForcaJog";
            this.lblFomeForcaJog.Size = new System.Drawing.Size(36, 19);
            this.lblFomeForcaJog.TabIndex = 3;
            this.lblFomeForcaJog.Tag = "";
            this.lblFomeForcaJog.Text = "0 %";
            // 
            // lblSonoForcaJog
            // 
            this.lblSonoForcaJog.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSonoForcaJog.AutoSize = true;
            this.lblSonoForcaJog.BackColor = System.Drawing.Color.Transparent;
            this.lblSonoForcaJog.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblSonoForcaJog.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSonoForcaJog.ForeColor = System.Drawing.Color.Black;
            this.lblSonoForcaJog.Location = new System.Drawing.Point(8, 305);
            this.lblSonoForcaJog.Name = "lblSonoForcaJog";
            this.lblSonoForcaJog.Size = new System.Drawing.Size(36, 19);
            this.lblSonoForcaJog.TabIndex = 4;
            this.lblSonoForcaJog.Tag = "";
            this.lblSonoForcaJog.Text = "0 %";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(61, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sono";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(61, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "Fome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(61, 375);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "Fúria/Explosividade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Cursor = System.Windows.Forms.Cursors.Default;
            this.label5.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(61, 423);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 19);
            this.label5.TabIndex = 11;
            this.label5.Text = "Sagacidade";
            // 
            // progressBarHumanasJog
            // 
            this.progressBarHumanasJog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarHumanasJog.Location = new System.Drawing.Point(65, 495);
            this.progressBarHumanasJog.Name = "progressBarHumanasJog";
            this.progressBarHumanasJog.Size = new System.Drawing.Size(221, 23);
            this.progressBarHumanasJog.TabIndex = 14;
            this.progressBarHumanasJog.Click += new System.EventHandler(this.progressBarHumanasJog_Click);
            // 
            // progressBarMalandragemJog
            // 
            this.progressBarMalandragemJog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarMalandragemJog.Location = new System.Drawing.Point(65, 445);
            this.progressBarMalandragemJog.Name = "progressBarMalandragemJog";
            this.progressBarMalandragemJog.Size = new System.Drawing.Size(221, 23);
            this.progressBarMalandragemJog.TabIndex = 12;
            this.progressBarMalandragemJog.Click += new System.EventHandler(this.progressBarMalandragemJog_Click);
            // 
            // progressBarRaivaJog
            // 
            this.progressBarRaivaJog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarRaivaJog.Location = new System.Drawing.Point(65, 397);
            this.progressBarRaivaJog.Name = "progressBarRaivaJog";
            this.progressBarRaivaJog.Size = new System.Drawing.Size(221, 23);
            this.progressBarRaivaJog.TabIndex = 10;
            this.progressBarRaivaJog.Click += new System.EventHandler(this.progressBarRaivaJog_Click);
            // 
            // progressBarFomeJog
            // 
            this.progressBarFomeJog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarFomeJog.Location = new System.Drawing.Point(65, 349);
            this.progressBarFomeJog.Name = "progressBarFomeJog";
            this.progressBarFomeJog.Size = new System.Drawing.Size(221, 23);
            this.progressBarFomeJog.TabIndex = 8;
            this.progressBarFomeJog.Click += new System.EventHandler(this.progressBarFomeJog_Click);
            // 
            // progressBarSonoJog
            // 
            this.progressBarSonoJog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarSonoJog.Location = new System.Drawing.Point(65, 301);
            this.progressBarSonoJog.Name = "progressBarSonoJog";
            this.progressBarSonoJog.Size = new System.Drawing.Size(221, 23);
            this.progressBarSonoJog.TabIndex = 6;
            this.progressBarSonoJog.Click += new System.EventHandler(this.progressBarSonoJog_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Cursor = System.Windows.Forms.Cursors.Default;
            this.label4.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(61, 471);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 19);
            this.label4.TabIndex = 13;
            this.label4.Text = "de Humanas";
            // 
            // ptbImagemCartaJog
            // 
            this.ptbImagemCartaJog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ptbImagemCartaJog.ImageLocation = "";
            this.ptbImagemCartaJog.Location = new System.Drawing.Point(65, 34);
            this.ptbImagemCartaJog.Name = "ptbImagemCartaJog";
            this.ptbImagemCartaJog.Size = new System.Drawing.Size(221, 243);
            this.ptbImagemCartaJog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbImagemCartaJog.TabIndex = 0;
            this.ptbImagemCartaJog.TabStop = false;
            // 
            // CartaCompFrente
            // 
            this.CartaCompFrente.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CartaCompFrente.BackgroundImage = global::teste2.Properties.Resources.cartaFrente;
            this.CartaCompFrente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CartaCompFrente.Controls.Add(this.lblCodigoComp);
            this.CartaCompFrente.Controls.Add(this.txbNomeComp);
            this.CartaCompFrente.Controls.Add(this.lblHumanasForcaComp);
            this.CartaCompFrente.Controls.Add(this.lblMalandragemForcaComp);
            this.CartaCompFrente.Controls.Add(this.lblRaivaForcaComp);
            this.CartaCompFrente.Controls.Add(this.lblFomeForcaComp);
            this.CartaCompFrente.Controls.Add(this.lblSonoForcaComp);
            this.CartaCompFrente.Controls.Add(this.label13);
            this.CartaCompFrente.Controls.Add(this.label14);
            this.CartaCompFrente.Controls.Add(this.label15);
            this.CartaCompFrente.Controls.Add(this.label16);
            this.CartaCompFrente.Controls.Add(this.progressBarHumanasComp);
            this.CartaCompFrente.Controls.Add(this.progressBarMalandragemComp);
            this.CartaCompFrente.Controls.Add(this.progressBarRaivaComp);
            this.CartaCompFrente.Controls.Add(this.progressBarFomeComp);
            this.CartaCompFrente.Controls.Add(this.progressBarSonoComp);
            this.CartaCompFrente.Controls.Add(this.label17);
            this.CartaCompFrente.Controls.Add(this.ptbImagemCartaComp);
            this.CartaCompFrente.Location = new System.Drawing.Point(0, 0);
            this.CartaCompFrente.Name = "CartaCompFrente";
            this.CartaCompFrente.Size = new System.Drawing.Size(358, 535);
            this.CartaCompFrente.TabIndex = 0;
            // 
            // lblCodigoComp
            // 
            this.lblCodigoComp.AutoSize = true;
            this.lblCodigoComp.BackColor = System.Drawing.Color.SkyBlue;
            this.lblCodigoComp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCodigoComp.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigoComp.ForeColor = System.Drawing.Color.Black;
            this.lblCodigoComp.Location = new System.Drawing.Point(17, 8);
            this.lblCodigoComp.Name = "lblCodigoComp";
            this.lblCodigoComp.Size = new System.Drawing.Size(2, 21);
            this.lblCodigoComp.TabIndex = 16;
            // 
            // txbNomeComp
            // 
            this.txbNomeComp.Location = new System.Drawing.Point(65, 8);
            this.txbNomeComp.Name = "txbNomeComp";
            this.txbNomeComp.ReadOnly = true;
            this.txbNomeComp.Size = new System.Drawing.Size(221, 20);
            this.txbNomeComp.TabIndex = 15;
            this.txbNomeComp.Text = "NOME";
            this.txbNomeComp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblHumanasForcaComp
            // 
            this.lblHumanasForcaComp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblHumanasForcaComp.AutoSize = true;
            this.lblHumanasForcaComp.BackColor = System.Drawing.Color.Transparent;
            this.lblHumanasForcaComp.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHumanasForcaComp.ForeColor = System.Drawing.Color.Black;
            this.lblHumanasForcaComp.Location = new System.Drawing.Point(13, 495);
            this.lblHumanasForcaComp.Name = "lblHumanasForcaComp";
            this.lblHumanasForcaComp.Size = new System.Drawing.Size(36, 19);
            this.lblHumanasForcaComp.TabIndex = 4;
            this.lblHumanasForcaComp.Tag = "";
            this.lblHumanasForcaComp.Text = "0 %";
            // 
            // lblMalandragemForcaComp
            // 
            this.lblMalandragemForcaComp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMalandragemForcaComp.AutoSize = true;
            this.lblMalandragemForcaComp.BackColor = System.Drawing.Color.Transparent;
            this.lblMalandragemForcaComp.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMalandragemForcaComp.ForeColor = System.Drawing.Color.Black;
            this.lblMalandragemForcaComp.Location = new System.Drawing.Point(13, 445);
            this.lblMalandragemForcaComp.Name = "lblMalandragemForcaComp";
            this.lblMalandragemForcaComp.Size = new System.Drawing.Size(36, 19);
            this.lblMalandragemForcaComp.TabIndex = 3;
            this.lblMalandragemForcaComp.Tag = "";
            this.lblMalandragemForcaComp.Text = "0 %";
            // 
            // lblRaivaForcaComp
            // 
            this.lblRaivaForcaComp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRaivaForcaComp.AutoSize = true;
            this.lblRaivaForcaComp.BackColor = System.Drawing.Color.Transparent;
            this.lblRaivaForcaComp.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRaivaForcaComp.ForeColor = System.Drawing.Color.Black;
            this.lblRaivaForcaComp.Location = new System.Drawing.Point(13, 397);
            this.lblRaivaForcaComp.Name = "lblRaivaForcaComp";
            this.lblRaivaForcaComp.Size = new System.Drawing.Size(36, 19);
            this.lblRaivaForcaComp.TabIndex = 2;
            this.lblRaivaForcaComp.Tag = "";
            this.lblRaivaForcaComp.Text = "0 %";
            // 
            // lblFomeForcaComp
            // 
            this.lblFomeForcaComp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFomeForcaComp.AutoSize = true;
            this.lblFomeForcaComp.BackColor = System.Drawing.Color.Transparent;
            this.lblFomeForcaComp.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFomeForcaComp.ForeColor = System.Drawing.Color.Black;
            this.lblFomeForcaComp.Location = new System.Drawing.Point(13, 349);
            this.lblFomeForcaComp.Name = "lblFomeForcaComp";
            this.lblFomeForcaComp.Size = new System.Drawing.Size(36, 19);
            this.lblFomeForcaComp.TabIndex = 1;
            this.lblFomeForcaComp.Tag = "";
            this.lblFomeForcaComp.Text = "0 %";
            // 
            // lblSonoForcaComp
            // 
            this.lblSonoForcaComp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSonoForcaComp.AutoSize = true;
            this.lblSonoForcaComp.BackColor = System.Drawing.Color.Transparent;
            this.lblSonoForcaComp.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSonoForcaComp.ForeColor = System.Drawing.Color.Black;
            this.lblSonoForcaComp.Location = new System.Drawing.Point(13, 305);
            this.lblSonoForcaComp.Name = "lblSonoForcaComp";
            this.lblSonoForcaComp.Size = new System.Drawing.Size(36, 19);
            this.lblSonoForcaComp.TabIndex = 0;
            this.lblSonoForcaComp.Tag = "";
            this.lblSonoForcaComp.Text = "0 %";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(61, 279);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 19);
            this.label13.TabIndex = 9;
            this.label13.Text = "Sono";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(61, 327);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 19);
            this.label14.TabIndex = 8;
            this.label14.Text = "Fome";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(61, 375);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(178, 19);
            this.label15.TabIndex = 7;
            this.label15.Text = "Fúria/Explosividade";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label16.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(61, 423);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 19);
            this.label16.TabIndex = 6;
            this.label16.Text = "Sagacidade";
            // 
            // progressBarHumanasComp
            // 
            this.progressBarHumanasComp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarHumanasComp.Location = new System.Drawing.Point(65, 495);
            this.progressBarHumanasComp.Name = "progressBarHumanasComp";
            this.progressBarHumanasComp.Size = new System.Drawing.Size(221, 23);
            this.progressBarHumanasComp.TabIndex = 14;
            // 
            // progressBarMalandragemComp
            // 
            this.progressBarMalandragemComp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarMalandragemComp.Location = new System.Drawing.Point(65, 445);
            this.progressBarMalandragemComp.Name = "progressBarMalandragemComp";
            this.progressBarMalandragemComp.Size = new System.Drawing.Size(221, 23);
            this.progressBarMalandragemComp.TabIndex = 13;
            // 
            // progressBarRaivaComp
            // 
            this.progressBarRaivaComp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarRaivaComp.Location = new System.Drawing.Point(65, 397);
            this.progressBarRaivaComp.Name = "progressBarRaivaComp";
            this.progressBarRaivaComp.Size = new System.Drawing.Size(221, 23);
            this.progressBarRaivaComp.TabIndex = 12;
            // 
            // progressBarFomeComp
            // 
            this.progressBarFomeComp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarFomeComp.Location = new System.Drawing.Point(65, 349);
            this.progressBarFomeComp.Name = "progressBarFomeComp";
            this.progressBarFomeComp.Size = new System.Drawing.Size(221, 23);
            this.progressBarFomeComp.TabIndex = 11;
            // 
            // progressBarSonoComp
            // 
            this.progressBarSonoComp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.progressBarSonoComp.Location = new System.Drawing.Point(65, 301);
            this.progressBarSonoComp.Name = "progressBarSonoComp";
            this.progressBarSonoComp.Size = new System.Drawing.Size(221, 23);
            this.progressBarSonoComp.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label17.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(61, 471);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(107, 19);
            this.label17.TabIndex = 5;
            this.label17.Text = "de Humanas";
            // 
            // ptbImagemCartaComp
            // 
            this.ptbImagemCartaComp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ptbImagemCartaComp.ImageLocation = "";
            this.ptbImagemCartaComp.Location = new System.Drawing.Point(65, 34);
            this.ptbImagemCartaComp.Name = "ptbImagemCartaComp";
            this.ptbImagemCartaComp.Size = new System.Drawing.Size(221, 243);
            this.ptbImagemCartaComp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbImagemCartaComp.TabIndex = 0;
            this.ptbImagemCartaComp.TabStop = false;
            // 
            // CartaJogVerso
            // 
            this.CartaJogVerso.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.CartaJogVerso.BackgroundImage = global::teste2.Properties.Resources.carta;
            this.CartaJogVerso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CartaJogVerso.Controls.Add(this.CartaJogFrente);
            this.CartaJogVerso.Location = new System.Drawing.Point(67, 98);
            this.CartaJogVerso.Name = "CartaJogVerso";
            this.CartaJogVerso.Size = new System.Drawing.Size(358, 535);
            this.CartaJogVerso.TabIndex = 40;
            // 
            // CartaCompVerso
            // 
            this.CartaCompVerso.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.CartaCompVerso.BackgroundImage = global::teste2.Properties.Resources.carta;
            this.CartaCompVerso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CartaCompVerso.Controls.Add(this.CartaCompFrente);
            this.CartaCompVerso.Location = new System.Drawing.Point(514, 98);
            this.CartaCompVerso.Name = "CartaCompVerso";
            this.CartaCompVerso.Size = new System.Drawing.Size(358, 535);
            this.CartaCompVerso.TabIndex = 41;
            // 
            // txbPontosJog
            // 
            this.txbPontosJog.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbPontosJog.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPontosJog.Location = new System.Drawing.Point(236, 52);
            this.txbPontosJog.Name = "txbPontosJog";
            this.txbPontosJog.ReadOnly = true;
            this.txbPontosJog.Size = new System.Drawing.Size(91, 40);
            this.txbPontosJog.TabIndex = 6;
            // 
            // txbPontosComp
            // 
            this.txbPontosComp.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbPontosComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbPontosComp.Location = new System.Drawing.Point(605, 52);
            this.txbPontosComp.Name = "txbPontosComp";
            this.txbPontosComp.ReadOnly = true;
            this.txbPontosComp.Size = new System.Drawing.Size(90, 40);
            this.txbPontosComp.TabIndex = 9;
            // 
            // lblPontosJog
            // 
            this.lblPontosJog.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblPontosJog.AutoSize = true;
            this.lblPontosJog.BackColor = System.Drawing.Color.Transparent;
            this.lblPontosJog.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontosJog.ForeColor = System.Drawing.Color.White;
            this.lblPontosJog.Location = new System.Drawing.Point(230, 16);
            this.lblPontosJog.Name = "lblPontosJog";
            this.lblPontosJog.Size = new System.Drawing.Size(105, 33);
            this.lblPontosJog.TabIndex = 3;
            this.lblPontosJog.Text = "Pontos";
            // 
            // lblPontosComp
            // 
            this.lblPontosComp.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblPontosComp.AutoSize = true;
            this.lblPontosComp.BackColor = System.Drawing.Color.Transparent;
            this.lblPontosComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontosComp.ForeColor = System.Drawing.Color.White;
            this.lblPontosComp.Location = new System.Drawing.Point(599, 16);
            this.lblPontosComp.Name = "lblPontosComp";
            this.lblPontosComp.Size = new System.Drawing.Size(105, 33);
            this.lblPontosComp.TabIndex = 1;
            this.lblPontosComp.Text = "Pontos";
            // 
            // lblVs
            // 
            this.lblVs.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblVs.AutoSize = true;
            this.lblVs.BackColor = System.Drawing.Color.Transparent;
            this.lblVs.Font = new System.Drawing.Font("Microsoft Sans Serif", 32.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVs.ForeColor = System.Drawing.Color.White;
            this.lblVs.Location = new System.Drawing.Point(425, 377);
            this.lblVs.Name = "lblVs";
            this.lblVs.Size = new System.Drawing.Size(82, 51);
            this.lblVs.TabIndex = 5;
            this.lblVs.Text = "VS";
            // 
            // txbTempoJogo
            // 
            this.txbTempoJogo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbTempoJogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTempoJogo.Location = new System.Drawing.Point(407, 52);
            this.txbTempoJogo.Name = "txbTempoJogo";
            this.txbTempoJogo.ReadOnly = true;
            this.txbTempoJogo.Size = new System.Drawing.Size(125, 40);
            this.txbTempoJogo.TabIndex = 10;
            // 
            // lblTempoJogo
            // 
            this.lblTempoJogo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblTempoJogo.AutoSize = true;
            this.lblTempoJogo.BackColor = System.Drawing.Color.Transparent;
            this.lblTempoJogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempoJogo.ForeColor = System.Drawing.Color.White;
            this.lblTempoJogo.Location = new System.Drawing.Point(415, 16);
            this.lblTempoJogo.Name = "lblTempoJogo";
            this.lblTempoJogo.Size = new System.Drawing.Size(106, 33);
            this.lblTempoJogo.TabIndex = 2;
            this.lblTempoJogo.Text = "Tempo";
            // 
            // TmTempoJogo
            // 
            this.TmTempoJogo.Enabled = true;
            this.TmTempoJogo.Interval = 10;
            this.TmTempoJogo.Tick += new System.EventHandler(this.TmTempoJogo_Tick);
            // 
            // txbCartasComp
            // 
            this.txbCartasComp.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbCartasComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbCartasComp.Location = new System.Drawing.Point(789, 52);
            this.txbCartasComp.Name = "txbCartasComp";
            this.txbCartasComp.ReadOnly = true;
            this.txbCartasComp.Size = new System.Drawing.Size(42, 40);
            this.txbCartasComp.TabIndex = 11;
            // 
            // txbCartasJog
            // 
            this.txbCartasJog.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbCartasJog.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbCartasJog.Location = new System.Drawing.Point(104, 52);
            this.txbCartasJog.Name = "txbCartasJog";
            this.txbCartasJog.ReadOnly = true;
            this.txbCartasJog.Size = new System.Drawing.Size(44, 40);
            this.txbCartasJog.TabIndex = 5;
            // 
            // lblCartasJog
            // 
            this.lblCartasJog.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblCartasJog.AutoSize = true;
            this.lblCartasJog.BackColor = System.Drawing.Color.Transparent;
            this.lblCartasJog.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCartasJog.ForeColor = System.Drawing.Color.White;
            this.lblCartasJog.Location = new System.Drawing.Point(46, 16);
            this.lblCartasJog.Name = "lblCartasJog";
            this.lblCartasJog.Size = new System.Drawing.Size(156, 33);
            this.lblCartasJog.TabIndex = 4;
            this.lblCartasJog.Text = "Qnt Cartas";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(731, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 33);
            this.label6.TabIndex = 0;
            this.label6.Text = "Qnt Cartas";
            // 
            // TempoPontos
            // 
            this.TempoPontos.Enabled = true;
            this.TempoPontos.Interval = 10;
            this.TempoPontos.Tick += new System.EventHandler(this.CompJoga_Tick);
            // 
            // frJogo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::teste2.Properties.Resources.SUPER_TRUNFO;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(934, 661);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblCartasJog);
            this.Controls.Add(this.txbCartasJog);
            this.Controls.Add(this.txbCartasComp);
            this.Controls.Add(this.lblTempoJogo);
            this.Controls.Add(this.txbTempoJogo);
            this.Controls.Add(this.lblVs);
            this.Controls.Add(this.lblPontosComp);
            this.Controls.Add(this.lblPontosJog);
            this.Controls.Add(this.txbPontosComp);
            this.Controls.Add(this.txbPontosJog);
            this.Controls.Add(this.CartaCompVerso);
            this.Controls.Add(this.CartaJogVerso);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frJogo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SUPER TRUNFO EC2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frJogo_Load);
            this.CartaJogFrente.ResumeLayout(false);
            this.CartaJogFrente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbImagemCartaJog)).EndInit();
            this.CartaCompFrente.ResumeLayout(false);
            this.CartaCompFrente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbImagemCartaComp)).EndInit();
            this.CartaJogVerso.ResumeLayout(false);
            this.CartaCompVerso.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel CartaJogFrente;
        private System.Windows.Forms.Label lblCodigoJog;
        private System.Windows.Forms.TextBox txbNomeJog;
        private System.Windows.Forms.Label lblHumanasForcaJog;
        private System.Windows.Forms.Label lblMalandragemForcaJog;
        private System.Windows.Forms.Label lblRaivaForcaJog;
        private System.Windows.Forms.Label lblFomeForcaJog;
        private System.Windows.Forms.Label lblSonoForcaJog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ProgressBar progressBarHumanasJog;
        private System.Windows.Forms.ProgressBar progressBarMalandragemJog;
        private System.Windows.Forms.ProgressBar progressBarRaivaJog;
        private System.Windows.Forms.ProgressBar progressBarFomeJog;
        private System.Windows.Forms.ProgressBar progressBarSonoJog;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox ptbImagemCartaJog;
        private System.Windows.Forms.Panel CartaCompFrente;
        private System.Windows.Forms.Label lblCodigoComp;
        private System.Windows.Forms.TextBox txbNomeComp;
        private System.Windows.Forms.Label lblHumanasForcaComp;
        private System.Windows.Forms.Label lblMalandragemForcaComp;
        private System.Windows.Forms.Label lblRaivaForcaComp;
        private System.Windows.Forms.Label lblFomeForcaComp;
        private System.Windows.Forms.Label lblSonoForcaComp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ProgressBar progressBarHumanasComp;
        private System.Windows.Forms.ProgressBar progressBarMalandragemComp;
        private System.Windows.Forms.ProgressBar progressBarRaivaComp;
        private System.Windows.Forms.ProgressBar progressBarFomeComp;
        private System.Windows.Forms.ProgressBar progressBarSonoComp;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox ptbImagemCartaComp;
        private System.Windows.Forms.Panel CartaJogVerso;
        private System.Windows.Forms.Panel CartaCompVerso;
        private System.Windows.Forms.TextBox txbPontosJog;
        private System.Windows.Forms.TextBox txbPontosComp;
        private System.Windows.Forms.Label lblPontosJog;
        private System.Windows.Forms.Label lblPontosComp;
        private System.Windows.Forms.Label lblVs;
        private System.Windows.Forms.TextBox txbTempoJogo;
        private System.Windows.Forms.Label lblTempoJogo;
        private System.Windows.Forms.Timer TmTempoJogo;
        private System.Windows.Forms.TextBox txbCartasComp;
        private System.Windows.Forms.TextBox txbCartasJog;
        private System.Windows.Forms.Label lblCartasJog;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Timer TempoPontos;
    }
}