﻿namespace teste2
{
    partial class frRecordes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frRecordes));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txbRecordesNome1 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome2 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome3 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome4 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome5 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome6 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome7 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome8 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome9 = new System.Windows.Forms.TextBox();
            this.txbRecordesNome10 = new System.Windows.Forms.TextBox();
            this.btnSairRecordes = new System.Windows.Forms.Button();
            this.txbRecordesPontos10 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos9 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos8 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos7 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos6 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos5 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos4 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos3 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos2 = new System.Windows.Forms.TextBox();
            this.txbRecordesPontos1 = new System.Windows.Forms.TextBox();
            this.lblRecordesNome = new System.Windows.Forms.Label();
            this.lblRecordesPontuacao = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(188, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "1º";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(188, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "2º";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(188, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 33);
            this.label3.TabIndex = 2;
            this.label3.Text = "3º";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(188, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 33);
            this.label4.TabIndex = 3;
            this.label4.Text = "4º";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(188, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 33);
            this.label5.TabIndex = 4;
            this.label5.Text = "5º";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(188, 301);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 33);
            this.label6.TabIndex = 5;
            this.label6.Text = "6º";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(188, 347);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 33);
            this.label7.TabIndex = 6;
            this.label7.Text = "7º";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(188, 393);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 33);
            this.label8.TabIndex = 7;
            this.label8.Text = "8º";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(188, 439);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 33);
            this.label9.TabIndex = 8;
            this.label9.Text = "9º";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(172, 485);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 33);
            this.label10.TabIndex = 9;
            this.label10.Text = "10º";
            // 
            // txbRecordesNome1
            // 
            this.txbRecordesNome1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome1.Location = new System.Drawing.Point(236, 64);
            this.txbRecordesNome1.Name = "txbRecordesNome1";
            this.txbRecordesNome1.ReadOnly = true;
            this.txbRecordesNome1.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome1.TabIndex = 10;
            // 
            // txbRecordesNome2
            // 
            this.txbRecordesNome2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome2.Location = new System.Drawing.Point(236, 110);
            this.txbRecordesNome2.Name = "txbRecordesNome2";
            this.txbRecordesNome2.ReadOnly = true;
            this.txbRecordesNome2.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome2.TabIndex = 11;
            // 
            // txbRecordesNome3
            // 
            this.txbRecordesNome3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome3.Location = new System.Drawing.Point(236, 156);
            this.txbRecordesNome3.Name = "txbRecordesNome3";
            this.txbRecordesNome3.ReadOnly = true;
            this.txbRecordesNome3.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome3.TabIndex = 12;
            // 
            // txbRecordesNome4
            // 
            this.txbRecordesNome4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome4.Location = new System.Drawing.Point(236, 202);
            this.txbRecordesNome4.Name = "txbRecordesNome4";
            this.txbRecordesNome4.ReadOnly = true;
            this.txbRecordesNome4.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome4.TabIndex = 13;
            // 
            // txbRecordesNome5
            // 
            this.txbRecordesNome5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome5.Location = new System.Drawing.Point(236, 248);
            this.txbRecordesNome5.Name = "txbRecordesNome5";
            this.txbRecordesNome5.ReadOnly = true;
            this.txbRecordesNome5.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome5.TabIndex = 14;
            // 
            // txbRecordesNome6
            // 
            this.txbRecordesNome6.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome6.Location = new System.Drawing.Point(236, 294);
            this.txbRecordesNome6.Name = "txbRecordesNome6";
            this.txbRecordesNome6.ReadOnly = true;
            this.txbRecordesNome6.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome6.TabIndex = 15;
            // 
            // txbRecordesNome7
            // 
            this.txbRecordesNome7.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome7.Location = new System.Drawing.Point(236, 340);
            this.txbRecordesNome7.Name = "txbRecordesNome7";
            this.txbRecordesNome7.ReadOnly = true;
            this.txbRecordesNome7.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome7.TabIndex = 16;
            // 
            // txbRecordesNome8
            // 
            this.txbRecordesNome8.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome8.Location = new System.Drawing.Point(236, 386);
            this.txbRecordesNome8.Name = "txbRecordesNome8";
            this.txbRecordesNome8.ReadOnly = true;
            this.txbRecordesNome8.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome8.TabIndex = 17;
            // 
            // txbRecordesNome9
            // 
            this.txbRecordesNome9.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome9.Location = new System.Drawing.Point(236, 432);
            this.txbRecordesNome9.Name = "txbRecordesNome9";
            this.txbRecordesNome9.ReadOnly = true;
            this.txbRecordesNome9.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome9.TabIndex = 18;
            // 
            // txbRecordesNome10
            // 
            this.txbRecordesNome10.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesNome10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesNome10.Location = new System.Drawing.Point(236, 478);
            this.txbRecordesNome10.Name = "txbRecordesNome10";
            this.txbRecordesNome10.ReadOnly = true;
            this.txbRecordesNome10.Size = new System.Drawing.Size(326, 40);
            this.txbRecordesNome10.TabIndex = 19;
            // 
            // btnSairRecordes
            // 
            this.btnSairRecordes.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSairRecordes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSairRecordes.ForeColor = System.Drawing.Color.Black;
            this.btnSairRecordes.Image = global::teste2.Properties.Resources._1495088327_22;
            this.btnSairRecordes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSairRecordes.Location = new System.Drawing.Point(416, 568);
            this.btnSairRecordes.Name = "btnSairRecordes";
            this.btnSairRecordes.Size = new System.Drawing.Size(105, 55);
            this.btnSairRecordes.TabIndex = 1;
            this.btnSairRecordes.Text = "Sair   ";
            this.btnSairRecordes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSairRecordes.UseVisualStyleBackColor = true;
            this.btnSairRecordes.Click += new System.EventHandler(this.btnSairRecordes_Click);
            // 
            // txbRecordesPontos10
            // 
            this.txbRecordesPontos10.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos10.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos10.Location = new System.Drawing.Point(599, 478);
            this.txbRecordesPontos10.Name = "txbRecordesPontos10";
            this.txbRecordesPontos10.ReadOnly = true;
            this.txbRecordesPontos10.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos10.TabIndex = 30;
            // 
            // txbRecordesPontos9
            // 
            this.txbRecordesPontos9.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos9.Location = new System.Drawing.Point(599, 432);
            this.txbRecordesPontos9.Name = "txbRecordesPontos9";
            this.txbRecordesPontos9.ReadOnly = true;
            this.txbRecordesPontos9.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos9.TabIndex = 29;
            // 
            // txbRecordesPontos8
            // 
            this.txbRecordesPontos8.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos8.Location = new System.Drawing.Point(599, 386);
            this.txbRecordesPontos8.Name = "txbRecordesPontos8";
            this.txbRecordesPontos8.ReadOnly = true;
            this.txbRecordesPontos8.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos8.TabIndex = 28;
            // 
            // txbRecordesPontos7
            // 
            this.txbRecordesPontos7.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos7.Location = new System.Drawing.Point(599, 340);
            this.txbRecordesPontos7.Name = "txbRecordesPontos7";
            this.txbRecordesPontos7.ReadOnly = true;
            this.txbRecordesPontos7.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos7.TabIndex = 27;
            // 
            // txbRecordesPontos6
            // 
            this.txbRecordesPontos6.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos6.Location = new System.Drawing.Point(599, 294);
            this.txbRecordesPontos6.Name = "txbRecordesPontos6";
            this.txbRecordesPontos6.ReadOnly = true;
            this.txbRecordesPontos6.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos6.TabIndex = 26;
            // 
            // txbRecordesPontos5
            // 
            this.txbRecordesPontos5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos5.Location = new System.Drawing.Point(599, 248);
            this.txbRecordesPontos5.Name = "txbRecordesPontos5";
            this.txbRecordesPontos5.ReadOnly = true;
            this.txbRecordesPontos5.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos5.TabIndex = 25;
            // 
            // txbRecordesPontos4
            // 
            this.txbRecordesPontos4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos4.Location = new System.Drawing.Point(599, 202);
            this.txbRecordesPontos4.Name = "txbRecordesPontos4";
            this.txbRecordesPontos4.ReadOnly = true;
            this.txbRecordesPontos4.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos4.TabIndex = 24;
            // 
            // txbRecordesPontos3
            // 
            this.txbRecordesPontos3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos3.Location = new System.Drawing.Point(599, 156);
            this.txbRecordesPontos3.Name = "txbRecordesPontos3";
            this.txbRecordesPontos3.ReadOnly = true;
            this.txbRecordesPontos3.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos3.TabIndex = 23;
            // 
            // txbRecordesPontos2
            // 
            this.txbRecordesPontos2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos2.Location = new System.Drawing.Point(599, 110);
            this.txbRecordesPontos2.Name = "txbRecordesPontos2";
            this.txbRecordesPontos2.ReadOnly = true;
            this.txbRecordesPontos2.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos2.TabIndex = 22;
            // 
            // txbRecordesPontos1
            // 
            this.txbRecordesPontos1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txbRecordesPontos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbRecordesPontos1.Location = new System.Drawing.Point(599, 64);
            this.txbRecordesPontos1.Name = "txbRecordesPontos1";
            this.txbRecordesPontos1.ReadOnly = true;
            this.txbRecordesPontos1.Size = new System.Drawing.Size(79, 40);
            this.txbRecordesPontos1.TabIndex = 21;
            // 
            // lblRecordesNome
            // 
            this.lblRecordesNome.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblRecordesNome.AutoSize = true;
            this.lblRecordesNome.BackColor = System.Drawing.Color.Transparent;
            this.lblRecordesNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecordesNome.ForeColor = System.Drawing.Color.White;
            this.lblRecordesNome.Location = new System.Drawing.Point(265, 28);
            this.lblRecordesNome.Name = "lblRecordesNome";
            this.lblRecordesNome.Size = new System.Drawing.Size(93, 33);
            this.lblRecordesNome.TabIndex = 31;
            this.lblRecordesNome.Text = "Nome";
            // 
            // lblRecordesPontuacao
            // 
            this.lblRecordesPontuacao.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblRecordesPontuacao.AutoSize = true;
            this.lblRecordesPontuacao.BackColor = System.Drawing.Color.Transparent;
            this.lblRecordesPontuacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecordesPontuacao.ForeColor = System.Drawing.Color.White;
            this.lblRecordesPontuacao.Location = new System.Drawing.Point(568, 28);
            this.lblRecordesPontuacao.Name = "lblRecordesPontuacao";
            this.lblRecordesPontuacao.Size = new System.Drawing.Size(153, 33);
            this.lblRecordesPontuacao.TabIndex = 32;
            this.lblRecordesPontuacao.Text = "Pontuação";
            // 
            // frRecordes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::teste2.Properties.Resources.super_trunfo_opaco;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(934, 661);
            this.Controls.Add(this.lblRecordesPontuacao);
            this.Controls.Add(this.lblRecordesNome);
            this.Controls.Add(this.txbRecordesPontos10);
            this.Controls.Add(this.txbRecordesPontos9);
            this.Controls.Add(this.txbRecordesPontos8);
            this.Controls.Add(this.txbRecordesPontos7);
            this.Controls.Add(this.txbRecordesPontos6);
            this.Controls.Add(this.txbRecordesPontos5);
            this.Controls.Add(this.txbRecordesPontos4);
            this.Controls.Add(this.txbRecordesPontos3);
            this.Controls.Add(this.txbRecordesPontos2);
            this.Controls.Add(this.txbRecordesPontos1);
            this.Controls.Add(this.btnSairRecordes);
            this.Controls.Add(this.txbRecordesNome10);
            this.Controls.Add(this.txbRecordesNome9);
            this.Controls.Add(this.txbRecordesNome8);
            this.Controls.Add(this.txbRecordesNome7);
            this.Controls.Add(this.txbRecordesNome6);
            this.Controls.Add(this.txbRecordesNome5);
            this.Controls.Add(this.txbRecordesNome4);
            this.Controls.Add(this.txbRecordesNome3);
            this.Controls.Add(this.txbRecordesNome2);
            this.Controls.Add(this.txbRecordesNome1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frRecordes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recordes";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txbRecordesNome1;
        private System.Windows.Forms.TextBox txbRecordesNome2;
        private System.Windows.Forms.TextBox txbRecordesNome3;
        private System.Windows.Forms.TextBox txbRecordesNome4;
        private System.Windows.Forms.TextBox txbRecordesNome5;
        private System.Windows.Forms.TextBox txbRecordesNome6;
        private System.Windows.Forms.TextBox txbRecordesNome7;
        private System.Windows.Forms.TextBox txbRecordesNome8;
        private System.Windows.Forms.TextBox txbRecordesNome9;
        private System.Windows.Forms.TextBox txbRecordesNome10;
        private System.Windows.Forms.Button btnSairRecordes;
        private System.Windows.Forms.TextBox txbRecordesPontos10;
        private System.Windows.Forms.TextBox txbRecordesPontos9;
        private System.Windows.Forms.TextBox txbRecordesPontos8;
        private System.Windows.Forms.TextBox txbRecordesPontos7;
        private System.Windows.Forms.TextBox txbRecordesPontos6;
        private System.Windows.Forms.TextBox txbRecordesPontos5;
        private System.Windows.Forms.TextBox txbRecordesPontos4;
        private System.Windows.Forms.TextBox txbRecordesPontos3;
        private System.Windows.Forms.TextBox txbRecordesPontos2;
        private System.Windows.Forms.TextBox txbRecordesPontos1;
        private System.Windows.Forms.Label lblRecordesNome;
        private System.Windows.Forms.Label lblRecordesPontuacao;
    }
}